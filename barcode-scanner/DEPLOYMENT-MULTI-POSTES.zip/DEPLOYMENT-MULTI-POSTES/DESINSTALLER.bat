@echo off
REM ============================================================================
REM  Désinstallation du Service Scanner de QR Codes
REM ============================================================================

echo.
echo ========================================================================
echo   Desinstallation du Scanner de Renouvellement d'Ordonnances
echo ========================================================================
echo.

REM Vérifier les droits administrateur
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo [ERREUR] Ce script doit etre execute en tant qu'administrateur
    echo.
    echo Faites un clic-droit sur le fichier et selectionnez
    echo "Executer en tant qu'administrateur"
    echo.
    pause
    exit /b 1
)

echo [OK] Droits administrateur detectes
echo.

set SERVICE_NAME=RenouvellementQRScanner

REM Vérifier si le service existe
sc query "%SERVICE_NAME%" >nul 2>&1
if %errorLevel% neq 0 (
    echo [INFO] Le service '%SERVICE_NAME%' n'est pas installe
    echo.
    pause
    exit /b 0
)

echo [Etape 1/3] Arret du service...
sc stop "%SERVICE_NAME%" >nul 2>&1
timeout /t 2 /nobreak >nul
echo [OK] Service arrete
echo.

echo [Etape 2/3] Suppression du service...
sc delete "%SERVICE_NAME%" >nul 2>&1
if %errorLevel% equ 0 (
    echo [OK] Service supprime
) else (
    echo [ERREUR] Impossible de supprimer le service
    pause
    exit /b 1
)
echo.

echo [Etape 3/3] Nettoyage...
timeout /t 2 /nobreak >nul
echo [OK] Nettoyage termine
echo.

echo ========================================================================
echo   Desinstallation terminee
echo ========================================================================
echo.
echo Le service '%SERVICE_NAME%' a ete desinstalle.
echo Les fichiers de l'application sont toujours presents.
echo Vous pouvez les supprimer manuellement si necessaire.
echo.
pause
